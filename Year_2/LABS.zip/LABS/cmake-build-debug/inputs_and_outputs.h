#include <stdbool.h>
#include <stdio.h>

#ifndef LABS_INPUTS_AND_OUTPUTS_H
#define LABS_INPUTS_AND_OUTPUTS_H
void palExtract(FILE *input, char mode); // Checks if string is a palindrome and writes accordingly.
bool isword(const char *str); // Ensures str is a word
#endif //LABS_INPUTS_AND_OUTPUTS_H
