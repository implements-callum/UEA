#ifndef LABS_C_FOR_SYSTEMS_H
#define LABS_C_FOR_SYSTEMS_H
// Checks if the binary representation of unsigned char has even or odd number of 1s.
unsigned parity(unsigned char x);
#endif //LABS_C_FOR_SYSTEMS_H
